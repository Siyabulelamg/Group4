<?php
session_start(); // Start the session

// Check if the user is logged in
$isLoggedIn = isset($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HomeFix Services</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #e0e0e0; /* Lighter gray for better contrast */
            line-height: 1.6; /* Improved readability */
        }

        /* Header Styles */
        .header {
            background-color: #2E8B57;
            color: white;
            padding: 20px 0;
            text-align: center;
        }

        .header h1 {
            margin: 0;
            font-size: 2.5rem;
            letter-spacing: 1px;
        }

        .header p {
            font-size: 1.2rem;
            margin-top: 10px;
            color: #E0E0E0;
        }

        /* Navigation Styles */
        .navbar {
            display: flex;
            justify-content: center;
            background-color: #333;
            padding: 10px 0;
        }

        .navbar a {
            color: white;
            padding: 14px 20px;
            text-decoration: none;
            text-transform: uppercase;
            font-weight: bold;
            font-size: 1rem;
            margin: 0 10px;
            transition: background-color 0.3s ease;
        }

        .navbar a:hover {
            background-color: #2E8B57;
            border-radius: 4px;
        }

        /* Banner Styles */
        .banner {
            background-image: url('banner.jpg'); /* Add a relevant banner image */
            background-size: cover;
            background-position: center;
            height: 60vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
            text-align: center;
            padding: 20px; /* Added padding for mobile responsiveness */
        }

        .banner h2 {
            font-size: 3rem;
            margin: 0;
        }

        .banner p {
            font-size: 1.5rem;
            margin-top: 20px;
        }

        /* Main Content Styles */
        .content {
            display: flex;
            justify-content: space-around;
            margin: 50px 0;
            flex-wrap: wrap; /* Allow cards to stack on smaller screens */
        }

        .card {
            background-color: #f9f9f9; /* Light gray for card background */
            width: 30%;
            padding: 20px; /* Reduced padding for compactness */
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            transition: transform 0.3s ease;
            margin: 15px; /* Added margin for spacing between cards */
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card img {
            width: 80px;
            margin-bottom: 20px;
        }

        .card h3 {
            font-size: 1.5rem; /* Slightly smaller for better balance */
            color: #333;
        }

        .card p {
            color: #555; /* Darker gray for text */
            font-size: 1rem;
            margin: 10px 0; /* Reduced margin for compactness */
        }

        .card a {
            background-color: #2E8B57;
            color: white;
            padding: 10px 15px; /* Adjusted padding for button */
            text-decoration: none;
            font-size: 1rem;
            border-radius: 4px;
            transition: background-color 0.3s ease;
            display: inline-block; /* Ensure it wraps properly */
            margin-top: 10px; /* Added margin for separation */
        }

        .card a:hover {
            background-color: #3C9E70;
        }

        /* Footer Styles */
        .footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 20px 0;
        }

        .footer p {
            margin: 0;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>

    <!-- Header Section -->
    <div class="header">
        <h1>HomeFix Services</h1>
        <p>Your Trusted Platform for Home Maintenance Solutions</p>
    </div>

    <!-- Navigation Bar -->
    <div class="navbar">
        <a href="register.php">Register</a>
        <a href="search.php">Search Services</a>
        <a href="add_service.php">Add Your Service</a>
        <?php if ($isLoggedIn): ?>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
        <?php endif; ?>
    </div>

    <!-- Banner Section -->
    <div class="banner">
        <div>
            <h2>Find the Right Experts for Your Home</h2>
            <p>From Plumbers to Painters, We Have Them All!</p>
        </div>
    </div>

    <!-- Main Content Section -->
    <div class="content">
        <div class="card">
            <img src="https://th.bing.com/th/id/OIP.6Tg7OjZEPpbOC5OeFRrqUAHaHx?rs=1&pid=ImgDetMain" alt="Register Icon">
            <h3>Become a Service Provider</h3>
            <p>Join our platform to offer your services to a wide range of clients.</p>
            <a href="register.php">Register Now</a>
        </div>

        <div class="card">
            <img src="https://th.bing.com/th/id/OIP.t1NpyhaiL4gouIOOsF6z0AHaHa?rs=1&pid=ImgDetMain" alt="Search Icon">
            <h3>Find a Service Provider</h3>
            <p>Search for verified service providers near you and get your job done.</p>
            <a href="search.php">Search Now</a>
        </div>

        <div class="card">
            <img src="https://th.bing.com/th/id/OIP.ShladOuCAgpVpJ_esuGtzQHaH0?rs=1&pid=ImgDetMain" alt="Service Icon">
            <h3>Offer Your Skills</h3>
            <p>Showcase your skills and grow your business by getting hired for local projects.</p>
            <a href="add_service.php">Add Your Service</a>
        </div>
    </div>

    <!-- Footer Section -->
    <div class="footer">
        <p>&copy; 2024 HomeFix Services. All Rights Reserved.</p>
    </div>

</body>
</html>

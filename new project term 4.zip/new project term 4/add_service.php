<?php
session_start();

// Ensure the user is logged in and is a service provider
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'service_provider') {
    echo "<p>Unauthorized access. Please log in as a service provider.</p>";
    exit();
}

try {
    // Connect to the SQLite database and set error mode to exceptions
    $pdo = new PDO('sqlite:C:/Users/Tarkisha/Desktop/homefix_services.db');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "<p>Database connection failed: " . htmlspecialchars($e->getMessage()) . "</p>";
    exit();
}

$success_message = '';
$error_message = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate and sanitize inputs
    $service_name = filter_input(INPUT_POST, 'service_name', FILTER_SANITIZE_STRING);
    $rate_per_hour = filter_input(INPUT_POST, 'rate_per_hour', FILTER_VALIDATE_FLOAT);
    $service_provider_id = $_SESSION['user_id']; // Assuming the user ID is stored in session

    if ($service_name && $rate_per_hour !== false) {
        try {
            // Prepare and execute the SQL query
            $stmt = $pdo->prepare("INSERT INTO services (service_name, rate_per_hour, service_provider_id) 
                                   VALUES (:service_name, :rate_per_hour, :service_provider_id)");
            $stmt->execute([
                ':service_name' => $service_name,
                ':rate_per_hour' => $rate_per_hour,
                ':service_provider_id' => $service_provider_id
            ]);
            $success_message = "Service added successfully!";
        } catch (PDOException $e) {
            $error_message = "Error adding service: " . htmlspecialchars($e->getMessage());
        }
    } else {
        $error_message = "Invalid input. Please ensure all fields are filled correctly.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Service</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
            color: #333;
        }

        .container {
            width: 80%;
            max-width: 600px;
            margin: 30px auto;
            background-color: white;
            padding: 25px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #2E8B57;
        }

        label {
            font-weight: bold;
            display: block;
            margin: 15px 0 5px;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        input[type="submit"] {
            background-color: #2E8B57;
            color: white;
            border: none;
            padding: 12px 20px;
            font-weight: bold;
            cursor: pointer;
            border-radius: 5px;
            margin-top: 20px;
            transition: background-color 0.3s ease;
            width: 100%;
        }

        input[type="submit"]:hover {
            background-color: #3C9E70;
        }

        .message {
            text-align: center;
            font-weight: bold;
            margin-top: 15px;
        }

        .success {
            color: green;
        }

        .error {
            color: red;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Add Service</h2>

        <!-- Display success or error messages -->
        <?php if (!empty($success_message)): ?>
            <p class="message success"><?= htmlspecialchars($success_message) ?></p>
        <?php elseif (!empty($error_message)): ?>
            <p class="message error"><?= htmlspecialchars($error_message) ?></p>
        <?php endif; ?>

        <form method="POST">
            <label for="service_name">Service Name:</label>
            <input type="text" name="service_name" id="service_name" required maxlength="255"><br>

            <label for="rate_per_hour">Rate per Hour (in Rands):</label>
            <input type="number" name="rate_per_hour" id="rate_per_hour" required min="0" step="0.01"><br>

            <input type="submit" value="Add Service">
        </form>
    </div>

</body>
</html>

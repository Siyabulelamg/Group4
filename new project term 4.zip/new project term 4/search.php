<?php
// Establish a connection to the SQLite database
$pdo = new PDO('sqlite:C:/Users/Tarkisha/Desktop/homefix_services.db'); // Update the path to your database

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $search_query = $_POST['search_query'];

    // Search for the service in the database
    $stmt = $pdo->prepare("SELECT service_providers.name, service_providers.surname, service_providers.email, services.rate_per_hour 
                           FROM services
                           JOIN service_providers ON services.service_provider_id = service_providers.id
                           WHERE services.service_name LIKE ?");
    $stmt->execute(['%' . $search_query . '%']);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Search</title>
    <style>
        /* Internal CSS Styles */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            color: #333;
        }

        .container {
            width: 80%;
            max-width: 600px;
            margin: 30px auto;
            background-color: white;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #2E8B57; /* Consistent dark green for headings */
        }

        label {
            font-weight: bold;
            display: block;
            margin: 15px 0 5px;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #2E8B57;
            color: white;
            border: none;
            padding: 10px 20px;
            text-transform: uppercase;
            font-weight: bold;
            cursor: pointer;
            border-radius: 4px;
            margin-top: 20px;
            transition: background-color 0.3s ease;
            width: 100%;
        }

        input[type="submit"]:hover {
            background-color: #3C9E70;
        }

        /* Results styling */
        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            background-color: #f0f0f0;
            margin: 10px 0;
            padding: 15px;
            border-radius: 4px;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Search for a Service</h2>

        <!-- Search Form -->
        <form method="POST">
            <label for="search_query">Search for a service:</label>
            <input type="text" name="search_query" placeholder="e.g., Painter" required><br>
            <input type="submit" value="Search">
        </form>

        <!-- Display Results -->
        <?php if (!empty($results)): ?>
            <h2>Available Services</h2>
            <ul>
                <?php foreach ($results as $result): ?>
                    <li>
                        Name: <?= htmlspecialchars($result['name'] . ' ' . $result['surname']) ?><br>
                        Contact: <?= htmlspecialchars($result['email']) ?><br>
                        Rate per Hour: <?= htmlspecialchars($result['rate_per_hour']) ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php elseif ($_SERVER['REQUEST_METHOD'] == 'POST'): ?>
            <p>No services found matching your query.</p>
        <?php endif; ?>
    </div>

</body>
</html>

<?php
// Start session
session_start();

// Connect to the database with error handling
try {
    $pdo = new PDO('sqlite:C:/Users/Tarkisha/Desktop/homefix_services.db');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . htmlspecialchars($e->getMessage()));
}

// Initialize error message
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_type = $_POST['user_type'];
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'];

    // Validate form fields
    if (!$email) {
        $error_message = "Please provide a valid email address.";
    } elseif (strlen($password) < 6) {
        $error_message = "Password must be at least 6 characters long.";
    } else {
        // Check if email is already registered
        $table = ($user_type == 'service_provider') ? 'service_providers' : 'clients';
        $stmt = $pdo->prepare("SELECT * FROM $table WHERE email = ?");
        $stmt->execute([$email]);
        $existing_user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existing_user) {
            $error_message = "This email is already registered.";
        } else {
            // Hash the password
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);

            // Insert into the correct table
            if ($user_type == 'service_provider') {
                $stmt = $pdo->prepare("INSERT INTO service_providers (name, surname, email, password) VALUES (?, ?, ?, ?)");
            } else {
                $stmt = $pdo->prepare("INSERT INTO clients (name, surname, email, password) VALUES (?, ?, ?, ?)");
            }

            // Execute and redirect
            $stmt->execute([$name, $surname, $email, $hashed_password]);
            $_SESSION['user_id'] = $pdo->lastInsertId(); // Store user ID in session
            $_SESSION['user_type'] = $user_type;
            header('Location: homepage.php'); // Redirect to homepage after registration
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            color: #333;
        }

        .container {
            width: 80%;
            max-width: 600px;
            margin: 30px auto;
            background-color: white;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #2E8B57;
        }

        label {
            font-weight: bold;
            display: block;
            margin: 15px 0 5px;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        select {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #2E8B57;
            color: white;
            border: none;
            padding: 10px 20px;
            text-transform: uppercase;
            font-weight: bold;
            cursor: pointer;
            border-radius: 4px;
            margin-top: 20px;
            transition: background-color 0.3s ease;
            width: 100%;
        }

        input[type="submit"]:hover {
            background-color: #3C9E70;
        }

        .error {
            color: red;
            text-align: center;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Registration Form</h2>
        <!-- Display error message -->
        <?php if (!empty($error_message)): ?>
            <div class="error"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>
        <form method="POST">
            <label for="user_type">I am a:</label>
            <select name="user_type" id="user_type" required>
                <option value="client">Client</option>
                <option value="service_provider">Service Provider</option>
            </select><br>

            <label for="name">Name:</label>
            <input type="text" name="name" required><br>

            <label for="surname">Surname:</label>
            <input type="text" name="surname" required><br>

            <label for="email">Email:</label>
            <input type="email" name="email" required><br>

            <label for="password">Password:</label>
            <input type="password" name="password" required><br>

            <input type="submit" value="Register">
        </form>
    </div>

</body>
</html>

<?php
session_start();

// Connect to the database
$pdo = new PDO('sqlite:C:/Users/Tarkisha/Desktop/homefix_services.db'); // Database path

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check in service providers table
    $stmt = $pdo->prepare("SELECT * FROM service_providers WHERE email = ?");
    $stmt->execute([$email]);
    $service_provider = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($service_provider && password_verify($password, $service_provider['password'])) {
        // Set session variables for service provider
        $_SESSION['user_id'] = $service_provider['provider_id'];
        $_SESSION['user_type'] = 'service_provider';
        header('Location: homepage.php'); // Redirect to homepage
        exit;
    }

    // Check in clients table
    $stmt = $pdo->prepare("SELECT * FROM clients WHERE email = ?");
    $stmt->execute([$email]);
    $client = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($client && password_verify($password, $client['password'])) {
        // Set session variables for client
        $_SESSION['user_id'] = $client['client_id'];
        $_SESSION['user_type'] = 'client';
        header('Location: homepage.php'); // Redirect to homepage
        exit;
    }

    // Invalid credentials
    $error_message = "Invalid email or password.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - HomeFix Services</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .login-container {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        .login-container h2 {
            margin-bottom: 20px;
            text-align: center;
        }
        .login-container input[type="text"], .login-container input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .login-container input[type="submit"] {
            background-color: #2E8B57;
            color: white;
            border: none;
            padding: 10px;
            width: 100%;
            border-radius: 4px;
            cursor: pointer;
        }
        .login-container input[type="submit"]:hover {
            background-color: #3C9E70;
        }
        .error {
            color: red;
            text-align: center;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <?php if (isset($error_message)): ?>
            <div class="error"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <form action="login.php" method="post">
            <input type="text" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="submit" value="Login">
        </form>
        <p style="text-align: center;">Don't have an account? <a href="register.php">Register here</a></p>
    </div>
</body>
</html>